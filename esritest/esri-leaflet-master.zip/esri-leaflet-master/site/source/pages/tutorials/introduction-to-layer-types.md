---
title: Introduction to Layer Types
description: Learn how to differentiate between the layer types that make up the ArcGIS platform.
layout: tutorials.hbs
---

# {{ page.data.title }}

{{ page.data.description }}

Coming Soon.